def test_generic() :
    a = 2
    b = 2
    assert a == b


def test_generic1() :
    a = 2
    b = 2
    assert a != b